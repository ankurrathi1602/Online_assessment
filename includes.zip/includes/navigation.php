        <?php include "includes/header.php"; ?>

        <nav class="navbar navbar-inverse navbar-fixed-top navb1" role="navigation" id="top">
            <div class="container">
            <!-- for mobile devices-->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php" style="color: black;">Online Assessment</a>
                </div>
                

                
            <!--navigations -->
                <div class="collapse navbar-collapse navbar-ex1-collapse">
                    <ul class="nav navbar-nav navbar-right side-nav">
                        <li class="active"><a href="index.php"><i class="fa fa-fw fa-home"></i>Home</a></li>
                        <li><a href="contact.php"><i class="fa fa-fw fa-user"></i>Contact</a></li>
                        <li><a href="">Help<i class="fa fa-fw fa-question"></i></a></li>
                        <li><a href="register.php">Register<i class="fa fa-fw fa-login"></i></a></li>
                        <li><a href="login.php">Login<i class="fa fa-fw fa-login"></i></a></li>
                        <li><a href=""><i class="fas fa-user-lock"></i> Admin</a></li>
                   
                    </ul>
                </div>
            </div>
        </nav>