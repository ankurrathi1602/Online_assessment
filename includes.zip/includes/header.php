<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Online Assessment Portal</title>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="It is a website to assess the skills of the individual.">
        <meta name="author" content="">
        <!-- this is core bootstrap css -->
        <link type="text/css" rel="stylesheet" href="css/bootstrap.min.css">
        <!-- Fontawesome -->
        <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
        <!-- custom css -->
        <link rel="stylesheet" href="css/blog_home.css" type="text/css">
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Acme" rel="stylesheet">
        <style>
            .grid{
                border: 1px solid gray;
                box-shadow: lightgray 5px 5px;
                padding: 10px;
                margin: 30px;
                border-radius: 10px;
                height: 350px;
            }
            .form1{
                border: 2px solid black;
                padding: 2% 5% 5% 5%;
                margin: 0 10% 5% 10%;
                border-radius: 10px;
                background: lightgray;
                
            }
            .center 
            {
                width: 100px;
                height: 100px;
                display: block;
                margin-right: auto;
                margin-left: auto;
                margin-bottom: 30px;
                border-radius: 50%;
            }
            .button1
            {
                margin: 0 15px 0 15px;
            }
        </style>
    </head>
    <body>
    <div>