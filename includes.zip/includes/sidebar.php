<div class="col-md-4 one">
                        <div class="well">
                            <form action="">
                            <div class="form-group">
                                <input type="text" name="input" class="form-control">
                            </div>
                            <button type="submit" class="btn btn-primary">Search</button>
                            </form>

                            
                        </div>
                        <div class="well">
                            Lorem, ipsum dolor sit amet consectetur adipisicing elit. Pariatur repellat, iste impedit laborum quisquam at possimus tempore qui cum facere deleniti enim quibusdam ab amet neque vel. Accusamus, molestias eos.

                        </div>


                    </div>