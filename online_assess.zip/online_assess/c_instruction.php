<?php
    include "includes/navigation.php";
 ?>
        <!--This is the page content-->
            <div class="container">
                <div class="row">
                <!-- Main page content-->
                <div class="col-lg-12 well">
                        <h1 class="center"><u>Instructions</u></h1>
                        <h2>Please read the instructions carefully before starting the exam:</h2>
                        <h3>&nbsp;&nbsp;&nbsp;General Instructions:-</h3>
                            <p>
                                <ol>
                                    <li>Total duration of the examination is 60 minutes.</li>
                                    <li>The clock will be set.The counter timer </li>
                                    <li></li>
                                </ol>
                            </p>
                            <a href="c_instruction.php" class="btn btn-primary">Start Exam!</a>
                
                    </div>

                </div>
            </div>
        <!--This is the footer-->
        <?php include "includes/footer.php";?>